this is the image software made by sakshi patil.
    this software give you feature to store your images on cloud(database)

 "query.sql" file in your mysql server

    for this type in cmd:

        cd   \xampp\mysql\bin
        mysql   -u   root   -p
        [Enter again]
        create database image;


        [then execute code under query.sql file in cmd (just copy and paste content of "query.sql" file)]