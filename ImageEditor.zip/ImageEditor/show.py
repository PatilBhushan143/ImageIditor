def dis():
    import mysql.connector
    from PIL import Image, ImageTk
    import io
    import tkinter as tk

    # Create a connection
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="image"  # Name of the database
    )

    # Create a cursor object
    cursor = mydb.cursor()

    # Prepare a query
    query = 'SELECT * FROM images'

    # Execute the query
    cursor.execute(query)

    # Create the main window
    root = tk.Tk()
    root.title("Image Gallery")
    root.geometry("800x600")

    # Create a canvas to hold the images
    canvas = tk.Canvas(root)
    canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

    # Create a scrollbar for the canvas
    scrollbar = tk.Scrollbar(root, orient=tk.VERTICAL, command=canvas.yview)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # Configure the canvas to use the scrollbar
    canvas.configure(yscrollcommand=scrollbar.set)
    canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

    # Create a frame inside the canvas to hold the images
    frame = tk.Frame(canvas)
    canvas.create_window((0,0), window=frame, anchor="nw")

    # Loop over the query results and display the images
    for i, result in enumerate(cursor.fetchall()):
        # Get the image data from the database
        img_data = result[1]

        # Convert the image data to a PIL Image object
        img = Image.open(io.BytesIO(img_data))

        # Resize the image to fit in the frame
        img.thumbnail((300, 300))

        # Convert the PIL Image to a Tkinter PhotoImage object
        photo = ImageTk.PhotoImage(img)

        # Create a label to display the image
        label = tk.Label(frame, image=photo)
        label.image = photo
        label.grid(row=i // 3, column=i % 3)

    # Start the main event loop
    root.mainloop()
dis()