from tkinter import *
from tkinter import filedialog
import mysql.connector
from io import BytesIO
import numpy as np 
import random

from PIL import ImageTk, Image, ImageEnhance, ImageFilter, ImageOps, ImageDraw
#import cv2

# <------Displaying Image------>
def displayimage(img):
    dispimage = ImageTk.PhotoImage(img)

    panel.create_image(0, 0, anchor=NW, image=dispimage)
    panel.image = dispimage


# <------Open images from file explorer------>
# def ChangeImg():
#     global img
#     imgname = filedialog.askopenfilename(title="Change Image")
#     if imgname:

#         displayimage(img)
#         img = Image.open(imgname)

#     current=0
#     undo_stack.clear()
#     undo_stack.append(img)

def ChangeImg():
    global img, image_name
    imgname = filedialog.askopenfilename(title="Change Image")

    if imgname:
        img = Image.open(imgname)
        img = img.resize((850, 650))
        displayimage(img)
        global current, undo_stack
        current = 0
        undo_stack.clear()
        undo_stack.append(img)

#  <------------creating window------->
mains = Tk()
# mains.geometry("1080x720")
space = (" ") * 215
# screen_width = mains.winfo_screenwidth()
# screen_height = mains.winfo_screenheight()

mains.geometry("1250x750")
# mains.geometry(f"{screen_width}x{screen_height}")
mains.title(f"{space}Image Editor")
mains.configure(bg='#333333')


# <------Blur effect on images------>
def blurr():
    global img
    img = img.filter(ImageFilter.BLUR)
    displayimage(img)

    global current, undo_stack
    undo_stack.append(img)
    current = current + 1


# <------Rotate------>
def rotate():
    global img
    img = img.rotate(90, expand=True)
    displayimage(img)

    global current, undo_stack
    undo_stack.append(img)
    current = current + 1

# <------crop function=====>
def crop():
    global img
    img = img.crop((100, 100, 400, 400))
    displayimage(img)

    global current, undo_stack
    undo_stack.append(img)
    current = current + 1




# <------Default image in editor------>
img = Image.open("icons\\GreenHills.jpg")
image_name = "test.png"
img = img.resize((850, 650))
#img.place(x=100, y=40)


current = 0
undo_stack = []
undo_stack.append(img)

# <--------Undo/Redo------->

def undo():
    global img
    global current  
    if current > 0:
        img = undo_stack[current - 1]
        displayimage(img) 
        current = current - 1
        print(current)

def redo():
    global img
    global current
    if len(undo_stack) -1 != current:
        img = undo_stack[current + 1]
        displayimage(img)
        current = current + 1
        print(current)


#-----------save the image -------#
def save():
    global img
    file_types = (("JPEG files", "*.jpg"), ("PNG files", "*.png"))
    file_path = filedialog.asksaveasfilename(defaultextension=".jpg", filetypes=file_types)
    
    if file_path:
        image = img
        image.save(file_path)
    
    
def black_white():
    global img 
    # img = img.filter(
    img = img.convert('L')
    displayimage(img)

    global current, undo_stack
    undo_stack.append(img)
    current = current + 1


def negative():
    global img 
    # img = img.point(lambda x: 255 - x)
    img = ImageOps.invert(img)
    displayimage(img)

    global current, undo_stack
    undo_stack.append(img)
    current = current + 1

def glitch():
    global img
    
    img = glitch_image(img)
    displayimage(img)

    global current, undo_stack
    undo_stack.append(img)
    current = current + 1

def glitch_image(image):
    # Convert image to numpy array
    img_array = np.array(image)
    
    # Split image into individual color channels
    r, g, b = img_array[:,:,0], img_array[:,:,1], img_array[:,:,2]
    
    # Randomly shift the color channels
    shift = random.randint(-50, 50)
    r = np.roll(r, shift, axis=1)
    shift = random.randint(-50, 50)
    g = np.roll(g, shift, axis=0)
    shift = random.randint(-50, 50)
    b = np.roll(b, shift, axis=1)
    
    # Merge the color channels back into an image
    img_array = np.dstack((r, g, b))
    glitched_image = Image.fromarray(np.uint8(img_array))
    
    return glitched_image




def sepia_effect(image):
    # Convert image to grayscale
    grayscale_image = ImageOps.grayscale(image)
    
    # Apply a colorize filter to create a sepia tone
    sepia_tone = (255, 240, 192)
    sepia_image = ImageOps.colorize(grayscale_image, "#000000", sepia_tone)
    
    return sepia_image


def pixelate_image(image, pixel_size):
    # Calculate pixelated size
    new_size = (image.size[0] // pixel_size, image.size[1] // pixel_size)
    
    # Resize image to pixelated size and back up to original size
    return image.resize(new_size).resize(image.size, resample=Image.NEAREST)

def solarize_image(image, threshold=128):
    # Convert image to grayscale
    grayscale_image = image.convert("L")
    
    # Apply Solarize filter
    solarized_image = Image.new("L", grayscale_image.size)
    pixels = grayscale_image.load()
    solarized_pixels = solarized_image.load()
    for i in range(grayscale_image.size[0]):
        for j in range(grayscale_image.size[1]):
            if pixels[i, j] < threshold:
                solarized_pixels[i, j] = pixels[i, j]
            else:
                solarized_pixels[i, j] = 255 - pixels[i, j]
    
    # Convert back to original mode
    solarized_image = solarized_image.convert(image.mode)
    
    return solarized_image


def mosaic_filter(image):
    # Load the image and get the size
    im = image
    width, height = im.size

    # Define the size of each mosaic block
    block_size = 10

    # Calculate the number of blocks in each dimension
    num_blocks_x = (width + block_size - 1) // block_size
    num_blocks_y = (height + block_size - 1) // block_size

    # Create a new image to hold the mosaic
    mosaic = Image.new("RGB", (num_blocks_x * block_size, num_blocks_y * block_size))

    # Loop through each block and set its color to the average color of the pixels in that block
    for x in range(num_blocks_x):
        for y in range(num_blocks_y):
            # Calculate the bounds of the block
            x1 = x * block_size
            y1 = y * block_size
            x2 = min(x1 + block_size, width)
            y2 = min(y1 + block_size, height)

            # Get the average color of the pixels in the block
            r, g, b = 0, 0, 0
            count = 0
            for i in range(x1, x2):
                for j in range(y1, y2):
                    pixel = im.getpixel((i, j))
                    r += pixel[0]
                    g += pixel[1]
                    b += pixel[2]
                    count += 1
            r //= count
            g //= count
            b //= count

            # Set the color of the block in the mosaic
            for i in range(x1, x2):
                for j in range(y1, y2):
                    mosaic.putpixel((i, j), (r, g, b))

    # Return the mosaic image
    return mosaic


def bokeh_filter(image):
    # Convert the image to RGBA mode if it's not already
    if image.mode != "RGBA":
        image = image.convert("RGBA")

    # Get the width and height of the image
    width, height = image.size

    # Create a new blank image to draw the bokeh on
    bokeh_image = Image.new("RGBA", (width, height), (0, 0, 0, 0))

    # Define the number of bokeh circles to draw
    num_bokeh_circles = 25

    # Draw the bokeh circles on the blank image
    draw = ImageDraw.Draw(bokeh_image)
    for i in range(num_bokeh_circles):
        # Define the radius and position of the bokeh circle
        radius = random.randint(5, 50)
        x = random.randint(0, width)
        y = random.randint(0, height)

        # Define the color of the bokeh circle
        r = random.randint(0, 255)
        g = random.randint(0, 255)
        b = random.randint(0, 255)
        alpha = random.randint(128, 255)
        color = (r, g, b, alpha)

        # Draw the bokeh circle
        draw.ellipse((x-radius, y-radius, x+radius, y+radius), fill=color)

    # Apply a Gaussian blur to the bokeh image
    bokeh_image = bokeh_image.filter(ImageFilter.GaussianBlur(radius=10))

    # Convert the original image to RGBA mode
    if image.mode != "RGBA":
        image = image.convert("RGBA")

    # Composite the bokeh image onto the original image
    result_image = Image.alpha_composite(image, bokeh_image)

    # Return the result image
    return result_image




def bokeh():
    global img
    img = bokeh_filter(img)
    displayimage(img)

    global current, undo_stack
    undo_stack.append(img)
    current = current + 1

def pixelate():
    global img
    img = pixelate_image(img, 10)
    displayimage(img)

    global current, undo_stack
    undo_stack.append(img)
    current = current + 1

def sepia():
    global img
    img = sepia_effect(img)
    displayimage(img)

    global current, undo_stack
    undo_stack.append(img)
    current = current + 1


def solarize():
    global img
    img = solarize_image(img)
    displayimage(img)

    global current, undo_stack
    undo_stack.append(img)
    current = current + 1


def login_popup():
    # Create popup window
    popup = Toplevel(mains)
    popup.title("Login")
    popup.geometry("300x200")

    # Create labels and entry fields
    label_username = Label(popup, text="Username:")
    label_username.pack(pady=10)
    entry_username = Entry(popup)
    entry_username.pack(pady=5)
    label_password = Label(popup, text="Password:")
    label_password.pack(pady=10)
    entry_password = Entry(popup, show="*")
    entry_password.pack(pady=5)

    # Create login button
    def login_button():
        username = entry_username.get()
        password = entry_password.get()
        if username == "admin" and password == "password":
            popup.destroy()
            popup.result = "sucess"
            return True
        else:
            label_error.config(text="Invalid login credentials")

    button_login = Button(popup, text="Login", command=login_button)
    button_login.pack(pady=10)

    # Create error label
    label_error = Label(popup, fg="red")
    label_error.pack(pady=10)

    # Wait for popup to close
    popup.wait_window()
    return popup.result

def save_image_to_database(img):

    # Create a connection
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="image"  # Name of the database
    )

    # Create a cursor object
    cursor = mydb.cursor()

    # Convert the PIL image to bytes
    
    img_bytes = BytesIO()
    img.save(img_bytes, format='png')
    img_bytes = img_bytes.getvalue()

    # Prepare a query
    query = 'INSERT INTO images(image_data) VALUES(%s)'

    # Execute the query and commit the database.
    cursor.execute(query, (img_bytes,))
    mydb.commit()


def save_in_db():
    if login_popup():
        global img  
        save_image_to_database(img)
    
def display_images():
    if login_popup():
        #if login success then it will show images in database
        import os
        os.system("python3 show.py")
       

# <------Creating panel to display image------>
panel = Canvas(mains, width=850, height=650, bg='#050505')
panel.place(x=100, y=70)
displayimage(img)

#  <--left panel---->
panel_for_left = Label(mains, bg='#1C1C1C', width=8, height=42)
panel_for_left.place(x=7, y=70)

#  <--top panel--->
#panel_for_top = Label(mains, bg='#1C1C1C', width=30, height=2)
#panel_for_top.place(x=120, y=5)

#  <---right panel--->
panel_for_right = Label(mains, bg="#1F1F1F", width=28, height=42)
panel_for_right.place(x=1050, y=70)

#  <----set image on buttons------->
image = PhotoImage(file="icons\\save.png")
button_for_save = Button(text='first', image=image, bg='black', fg='black', activebackground='black', relief=SOLID,
                         command=save)
button_for_save.place(x=220, y=25)

image2 = PhotoImage(file="icons\\undo.png")
button_for_undo = Button(text='undo', image=image2, bg='black', fg='black', activebackground='black', relief=SOLID,
command=undo)
button_for_undo.place(x=150, y=25)

image3 = PhotoImage(file="icons\\redo.png")
button_for_redo = Button(text='undo', image=image3, bg='black', fg='black', activebackground='black', relief=SOLID,
command=redo)
button_for_redo.place(x=185, y=25)

image1 = PhotoImage(file="icons\\rotate.png")
button_for_rotate = Button(mains, text='first', image=image1, bg='black', fg='black', activebackground='black', command=rotate,
                relief=SOLID)
button_for_rotate.place(x=25, y=75)

image4 = PhotoImage(file="icons\\blur.png")
button_for_blur = Button(mains, text='undo', image=image4, bg='black', fg='black', activebackground='black',
                         relief=SOLID, command=blurr)
button_for_blur.place(x=25, y=130)

image5 = PhotoImage(file="icons\\open.png")
button_for_open = Button(mains, text='open', image=image5, bg='black', fg='black', activebackground='black',
                         relief=SOLID, command=ChangeImg)
button_for_open.place(x=115, y=25)

image6 = PhotoImage(file="icons\\bw.png")
button_for_bw = Button(mains, text='first', image=image6, bg='black', fg='black', activebackground='black', command=black_white,
                relief=SOLID)
button_for_bw.place(x=25, y=185)

image7 = PhotoImage(file="icons\\negative.png")
button_for_negative = Button(mains, text='first', image=image7, bg='black', fg='black', activebackground='black', command=negative,
                relief=SOLID)
button_for_negative.place(x=25, y=240)

image9 = PhotoImage(file="icons\\cloud.png")
button_for_save_in_db = Button(mains, text='first', image=image9, bg='black', fg='black', activebackground='black', command=save_in_db,
                relief=SOLID)
button_for_save_in_db.place(x=910, y=25)

image8 = PhotoImage(file="icons\\glitch.png")
button_for_glitch = Button(mains, text='first', image=image8, bg='black', fg='black', activebackground='black', command=glitch,
                relief=SOLID)
button_for_glitch.place(x=25, y=295)


image10 = PhotoImage(file="icons\\sepia.png")
button_for_sepia = Button(mains, text='first', image=image10, bg='black', fg='black', activebackground='black', command=sepia,
                relief=SOLID)
button_for_sepia.place(x=25, y=350)

image11 = PhotoImage(file="icons\\bokeh.png")
button_for_bokeh = Button(mains, text='first', image=image11, bg='black', fg='black', activebackground='black', command=bokeh,
                relief=SOLID)
button_for_bokeh.place(x=25, y=405)

image12 = PhotoImage(file="icons\\pixelate.png")
button_for_pixelate = Button(mains, text='first', image=image12, bg='black', fg='black', activebackground='black', command=pixelate,
                relief=SOLID)
button_for_pixelate.place(x=25, y=515)

image13 = PhotoImage(file="icons\\solarize.png")
button_for_mosaic = Button(mains, text='first', image=image13, bg='black', fg='black', activebackground='black', command=solarize,
                relief=SOLID)
button_for_mosaic.place(x=25, y=460)

image14 = PhotoImage(file="icons\\gallery.png")
button_for_show_in_db = Button(mains, text='first', image=image14, bg='black', fg='black', activebackground='black', command=display_images,
                relief=SOLID)
button_for_show_in_db.place(x=870, y=25)

#SLIDERS-----


# <------Contrast Slider------>
def contrast_callback(contrast_pos):
    contrast_pos = float(contrast_pos)
    # print(contrast_pos)
    global outputImage
    enhancer = ImageEnhance.Contrast(img)
    outputImage = enhancer.enhance(contrast_pos)
    displayimage(outputImage)

    global  current, undo_stack
    undo_stack.append(outputImage)
    current= current + 1


# <------Sharpness Slider------>
def sharpen_callback(sharpness_pos):
    sharpness_pos = float(sharpness_pos)
    global outputImage
    enhancer = ImageEnhance.Sharpness(img)
    outputImage = enhancer.enhance(sharpness_pos)
    displayimage(outputImage)

    global  current, undo_stack
    undo_stack.append(outputImage)
    current= current + 1

# <------Color slider------>
def color_callback(Color_pos):
    Color_pos = float(Color_pos)
    global outputImage
    enhancer = ImageEnhance.Color(img)
    outputImage = enhancer.enhance(Color_pos)
    displayimage(outputImage)

    global  current, undo_stack
    undo_stack.append(outputImage)
    current= current + 1

# def shadow_callback(Shadow_pos):
    # Shadow_pos =float(Shadow_pos)
    # global outputImage
    # enhancer = ImageEnhance.Shadow(img)
    # outputImage = enhancer.enhance(Shadow_pos)
    # displayimage(outputImage)

    # global current, undo_stack
    # undo_stack.append(outputImage)
    # current = current + 1

# <------Brightness Slider------>
def brightness_callback(brightness_pos):
    brightness_pos = float(brightness_pos)
    # print(brightness_pos)
    global outputImage
    enhancer = ImageEnhance.Brightness(img)
    outputImage = enhancer.enhance(brightness_pos)
    displayimage(outputImage)

    global current, undo_stack
    undo_stack.append(outputImage)
    current = current + 1

#measurment---------------------------------------------Sliers---------------------------------------------

# <------Brightness Slider button------>
brightnessSlider = Scale(mains, from_=0, to=2, orient=HORIZONTAL, length=200, label='Brightness',
                         resolution=0.01, bg="black", width=10, showvalue=2, activebackground='blue',
                         troughcolor='#808080', command=brightness_callback)
brightnessSlider.set(1)
brightnessSlider.configure(font=('consolas', 10, 'bold'), foreground='#DBDBDB', border=0, borderwidth=0)
brightnessSlider.place(x=1000, y=90)

# <------Contrast Slider button------>
contrastSlider = Scale(mains, from_=0, to=2, orient=HORIZONTAL, length=200, label='Contrast',
                       resolution=0.01, bg="black", width=10, showvalue=2, activebackground='blue',
                       troughcolor='#808080', command=contrast_callback)
contrastSlider.set(1)
contrastSlider.configure(font=('consolas', 10, 'bold'), foreground='#DBDBDB', border=0, borderwidth=0)
contrastSlider.place(x=1000, y=185)

# <------Sharpness Slider button------>
sharpnessSlider = Scale(mains, from_=0, to=2, orient=HORIZONTAL, length=200, label='Sharpness',
                        resolution=0.01, bg="black", width=10, showvalue=2, activebackground='blue',
                        troughcolor='#808080', command=sharpen_callback)
sharpnessSlider.set(1)
sharpnessSlider.configure(font=('consolas', 10, 'bold'), foreground='#DBDBDB', border=0, borderwidth=0)
sharpnessSlider.place(x=1000, y=285)

# <------Color Slider button------>
colorSlider = Scale(mains,from_=0, to=2, orient=HORIZONTAL, length=200, label='Colour',
                        resolution=0.01, bg="black", width=10, showvalue=2, activebackground='blue',
                        troughcolor='#808080', command=color_callback)
colorSlider.set(1)
colorSlider.configure(font=('consolas',10,'bold'),foreground='#DBDBDB')
colorSlider.place(x=1000,y=385)

# <------Shadow Slider button------>
# shadowSlider = Scale(mains,from_=0, to=2, orient=HORIZONTAL, length=200, label='Shadow',
#                         resolution=0.01, bg="black", width=10, showvalue=2, activebackground='blue',
#                         troughcolor='#808080', command=shadow_callback)
# shadowSlider.set(1)
# shadowSlider.configure(font=('consolas',10,'bold'),foreground='#DBDBDB')
# shadowSlider.place(x=1100,y=400)





mains.mainloop()